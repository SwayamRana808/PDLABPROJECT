const express = require('express');
const { createSensorData } = require('../controllers/sensorController');

const router = express.Router();

router.post('/data', createSensorData);

module.exports = router;
